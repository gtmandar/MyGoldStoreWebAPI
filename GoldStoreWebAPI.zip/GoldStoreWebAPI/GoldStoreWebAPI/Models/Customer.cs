﻿namespace GoldStoreWebAPI.Models
{
    public class Customer
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public string MobileNumber { get; set; }
        public string OrnamentName { get; set; }
        public double Weight { get; set; }
        public double Price { get; set; }
        public DateTime OrederDate { get; set; }
        public DateTime DeliveryDate { get; set; }




    }
}
