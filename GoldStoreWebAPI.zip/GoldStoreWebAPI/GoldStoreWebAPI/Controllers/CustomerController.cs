﻿using GoldStoreWebAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace GoldStoreWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerController : ControllerBase
    {
        private readonly CustomerContext _customerContext;

        public CustomerController(CustomerContext customerContext)
        {
            _customerContext = customerContext;
        }

        [HttpGet]

        public async Task<ActionResult<IEnumerable<Customer>>>  GetCustomers()
        {
            if(_customerContext.Customers == null)
            {
                return NotFound();
            }

            return await _customerContext.Customers.ToListAsync();
        }

        [HttpGet ("{id}")]
        public async Task<ActionResult<Customer>> GetCustomerById(int id)
        {
            if (_customerContext.Customers == null)
            {
                return NotFound();
            }
            var customer = await _customerContext.Customers.FindAsync(id);
            if (customer == null)
            {
                return NotFound();
            }

            return customer;
        }

        [HttpPost]
        public async Task<ActionResult<Customer>> AddCustomer(Customer addCustomer)
        {

            addCustomer.ID = 0;

            _customerContext.Customers.Add(addCustomer);
            await _customerContext.SaveChangesAsync();

            return CreatedAtAction(nameof(GetCustomerById), new { id = addCustomer.ID }, addCustomer);
        }
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateCustomer(int id, Customer updatedCustomer)
        {
            if (id != updatedCustomer.ID)
            {
                return BadRequest();
            }

            _customerContext.Entry(updatedCustomer).State = EntityState.Modified;

            try
            {
                await _customerContext.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CustomerExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult<Customer>> DeleteCustomer(int id)
        {
            var customer = await _customerContext.Customers.FindAsync(id);
            if (customer == null)
            {
                return NotFound();
            }

            _customerContext.Customers.Remove(customer);
            await _customerContext.SaveChangesAsync();

            return customer;
        }

        private bool CustomerExists(int id)
        {
            return _customerContext.Customers.Any(e => e.ID == id);
        }


    }
}
